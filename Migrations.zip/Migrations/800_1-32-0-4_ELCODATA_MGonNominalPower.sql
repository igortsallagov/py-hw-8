DELETE FROM
	T_MG
WHERE
	object_name in ('Nominal Power Max','Nominal Power PhA (V.A)','Nominal Power PhB (V.A)','Nominal Power PhC (V.A)')
