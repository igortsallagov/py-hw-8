UPDATE 
	APPLICATION_SETUP
SET
	application_patch = '3.0',
	application_version = '2.1'