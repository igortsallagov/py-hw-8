update
	infobase
set
	type_val='int'
where
	object_value='PCDContPin'
	and table_name='r_fin_ds'







