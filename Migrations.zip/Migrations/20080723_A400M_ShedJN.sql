-- A400M Force MG 2

declare @id_ds integer

-- 2751CVDC000001
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '2751CVDC000001')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2'
where id_ds = @id_ds

-- 3162WTDC000009
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000009')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000011
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000011')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000013
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000013')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000015
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000015')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000017
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000017')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000019
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000019')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000021
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000021')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000023
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000023')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000024
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000024')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 2592MYDC000005
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '2592MYDC000005')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000025
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000025')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 9951ADDC000004
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '9951ADDC000004')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 9951ADDC000005
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '9951ADDC000005')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 9951ADDC000006
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '9951ADDC000006')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3162WTDC000026
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3162WTDC000026')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 9951ADDC000007
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '9951ADDC000007')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 9951ADDC000008
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '9951ADDC000008')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 9951ADDC000009
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '9951ADDC000009')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 9951ADDC000010
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '9951ADDC000010')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds

-- 3321LGDC000008
set @id_ds = (select id_ds from r_fin_ds where substring(eddreference,1,14) = '3321LGDC000008')

update R_FIN_DS 
set 
 VALM1 ='Validated'
,MG='2' 
where id_ds = @id_ds
