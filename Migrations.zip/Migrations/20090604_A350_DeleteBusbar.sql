/*****************************
** DELETE BUSBAR => 120PN  **
*****************************/
DELETE FROM T_CHOICELIST WHERE choicelist = 'Busbar' AND ChoiceValue= '120PN'
