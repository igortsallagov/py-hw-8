Update
	r_fin_ds
set
	RCCB_AFD_Option=null
where
	RCCB_AFD_Option='Not activated'