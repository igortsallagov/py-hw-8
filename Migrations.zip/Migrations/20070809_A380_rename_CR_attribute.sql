-- program A380
-- Rename attribute label
UPDATE Infobase SET object_name = 'Forecast Date for Study Summary' WHERE object_value = 'cr_EVCRESADateF' AND table_name = 'V_CR'