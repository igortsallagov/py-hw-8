Update
	V_RFC
SET
	rfc_EVCRLTaDateF = NULL,
	rfc_EVCRLTaDateT = NULL,
	rfc_EVCRLTiTDateA = NULL,
	rfc_EVCRTRSaDateF = NULL,
	rfc_EVCRTRSaDateT = NULL,
	rfc_EVCRTRSiTDateA = NULL
WHERE
	rfc_RequestReference = 'SIA44L050H'

Update
	V_RFC
SET
	rfc_EVCRLTaDateF = NULL,
	rfc_EVCRLTaDateT = NULL,
	rfc_EVCRLTiTDateA = NULL,
	rfc_EVCRTRSaDateF = NULL,
	rfc_EVCRTRSaDateT = NULL,
	rfc_EVCRTRSiTDateA = NULL
WHERE
	rfc_RequestReference = 'THA44L008H'